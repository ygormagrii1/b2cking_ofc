import React from "react";
import { useCssHandles } from "vtex.css-handles";
import "./components/css/product.css";

// Adicionar aqui todas as classes
const CSS_HANDLES = ["aviso12d"];

const AvisosProduto = () => {
  const handles = useCssHandles(CSS_HANDLES);
  //console.log(handles)

  return (
    <div className="b2ckingbrasil-store-theme-1-x-alinhaAviso">

      <div className="b2ckingbrasil-store-theme-1-x-aviso12d">
       Em caso de personalização, considerar prazo de produção 20 dias úteis.
      </div>
      <br />
      <img src="https://b2ckingbrasil.vteximg.com.br/arquivos/compra-segura.jpg" width="50%" className="b2ckingbrasil-store-theme-1-x-imgAviso" />

    </div>

  );
};

export default AvisosProduto;
